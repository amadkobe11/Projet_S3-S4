package systeme;

public abstract class Jeton {
	int valeur;
	public Jeton(int v) {
		this.valeur=v;
	}
}

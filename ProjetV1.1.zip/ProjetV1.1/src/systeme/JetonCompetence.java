package systeme;

public class JetonCompetence extends Jeton {

	public JetonCompetence() {
		super(4);
	}
}

package systeme;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import interfaces.Joueurinterface;

public class Joueur implements Joueurinterface {
	private String nom;
	private String prenom;
	private int score;
	private TasJeton jetonsCoupDePouce;
	private TasJeton jetonsCompetence;
	private TasPotion potionTerminer;
	private Paillasse paillasse;
	private Reserve reserve;
	private List<Bille> main;
	private WindowGame window;
	
	public Joueur(String nom, String prenom, WindowGame window) {
		this.nom = nom;
		this.prenom = prenom;
		this.score = 0;
		this.jetonsCoupDePouce = new TasJetonCoupDePouce(0);
		this.jetonsCompetence = new TasJetonCompetence(0);
		this.potionTerminer = new TasPotion();
		this.paillasse = new Paillasse(this);
		this.reserve=new Reserve(this);
		this.main = new ArrayList<Bille>();
		this.window = window;
	}
	
	public void utiliserPotion(Potion p) throws RemoteException {
		if(this.potionTerminer.getPotion().contains(p) && p.isFinish()) {
			p.utiliserEffet();
		}
	}
	public void recevoirPCompetence() throws RemoteException {
		if(!this.window.getTasJetonCompetence().isEmpty()) {
			jetonsCompetence.addJeton(this.window.getTasJetonCompetence().prendreJeton());
			if(this.window.getTasJetonCompetence().isEmpty()) {
				this.window.FinirPartie();
			}
		}else {
			this.window.FinirPartie();
		}
	}
	public void placerBille(Bille b,int numPotion) throws RemoteException{
		
		Potion p = this.getPotionPaillasse().get(numPotion);
		if(!p.isFinish()) {
			if(b.getCouleur().equals("Noir")) {
				if(p.getTrouNoir()!=0) {
					p.placerBille(b);
				}
			}else if(b.getCouleur().equals("Jaune")){
				if(p.getTrouJaune()!=0) {
					p.placerBille(b);
				}
			}else if(b.getCouleur().equals("Rouge")) {
				if(p.getTrouRouge()!=0) {
					p.placerBille(b);
				}
			}else if(b.getCouleur().equals("Bleue")) {
				if(p.getTrouBleu()!=0) {
					p.placerBille(b);
				}
			}
			//le met en terminer s'il n'y a plus de trou vide
			if(p.getTrouNoir()==0 && p.getTrouBleu()==0 && p.getTrouJaune()==0 && p.getTrouRouge()==0){
				if(p.getEtat().equals("pioch�e")) {
					p.nextEtat();
					
					
					this.potionTerminer.getPotion().add(p);
					this.paillasse.getPotions().remove(p);
					List<Bille> bille = p.getBilles();
					
					//enlever les billes de la potion
					p.getBilles().removeAll(p.getBilles());
					
					//mettre les billes dans le distributeur
					this.window.distribuer(bille);
					
					//surement devoir mettre le piochage par rapport a la vue
					
				}
			}
		}else {
			//ne devrai pas arriver
		}
		
	}
	public void placerBille(Bille b) throws RemoteException {
		if(this.reserve.getBilles().size()<3) {
			this.reserve.getBilles().add(b);
		}else {
			//reserve pleine : plus de place dans la r�serve (vue)
		}
	}
	public void prendreJetonCoupDePouce() throws RemoteException{
		jetonsCoupDePouce.addJeton(window.getTasJetonCoupDePouce().prendreJeton());
	}
	public List<Potion> getPotionTermine() throws RemoteException{
		return this.potionTerminer.getPotion();
	}
	public List<Potion> getPotionPaillasse() throws RemoteException{
		return this.paillasse.getPotions();
	}
	public void PrendrePotion(int numPioche) throws RemoteException{
		if(this.paillasse.getPotions().size()<2) {
			if(!this.window.getPioche().get(numPioche).isEmpty()) {
				
				this.paillasse.getPotions().add(this.window.getPioche().get(numPioche).retirerPotion());
				
				//verifie si la partie se termine
				this.window.piocheVide();
			}else {
				//lui dire qu'il doit choisir autre chose ?
			}
		}
	}
	public void setScore(int score) throws RemoteException {
		this.score=score;
	}
	public void refreshScore() throws RemoteException{
		int sco = 0;
		//score pour les jetons competence
		sco = sco + 4*this.jetonsCompetence.getNbElement();
		//score pour les jetons coup de pouce
		sco = sco + (-2)*this.jetonsCoupDePouce.getNbElement();
		//score pour les potions
		for(int i=0;i<this.potionTerminer.getNbElement();i++) {
			sco = sco + this.potionTerminer.getPotion().get(i).getPuissance();
		}
		this.score=sco;
	}
	public void remettreBille() throws RemoteException{
		this.window.distribuer(main);
	}
	
	public void retirerBille(int ligne,int bille) throws RemoteException{
		this.main.addAll(this.window.getDistributeur().retirerBille(ligne, bille));
	}
	public List<Bille> getMain() throws RemoteException{
		return this.main;
	}
	public static void main(String[] args) {
		try {
			List<String> pj = new ArrayList<String>();
			List<String> nj = new ArrayList<String>();
			List<String> pb = new ArrayList<String>();
			
			pj.add("Gaylord");
			pj.add("Amadou");
			pj.add("Adrien");
			
			nj.add("Delporte");
			nj.add("Gacko");
			nj.add("Chauvency");
			
			pb.add("Filtre de lavamancie");
			pb.add("Baume de viscosit� supr�me");
			WindowGame wg = new WindowGame(4,"Bryan","Moreau",pj,nj,pb);
			
			Joueurinterface monint = wg.getJoueurPropri();
			Joueurinterface monint2 = wg.getAutreJoueur().get(0);
			Joueurinterface monint3 = wg.getAutreJoueur().get(1);
			Joueurinterface monint4 = wg.getAutreJoueur().get(2);
			try {
				/* if(System.getSecurityManager() ==null){
				 * 	System.setSecurityManager(new SecurityManager());
				 * }
				 */
				//
				Joueurinterface skeleton = (Joueurinterface) UnicastRemoteObject.exportObject(monint,2009);
				String name = new String("rmi://serveurProprietaire");
				Registry registry = LocateRegistry.createRegistry(2009);
				registry.rebind(name, skeleton);
				System.out.println("Serveur Waiting...");
				//
				
				Joueurinterface skeleton2 = (Joueurinterface) UnicastRemoteObject.exportObject(monint2,2010);
				String name2 = new String("rmi://serveurProprietaire");
				Registry registry2 = LocateRegistry.createRegistry(2010);
				registry2.rebind(name2, skeleton2);
				System.out.println("Serveur Waiting...");
				//
				Joueurinterface skeleton3 = (Joueurinterface) UnicastRemoteObject.exportObject(monint3,2011);
				String name3 = new String("rmi://serveurProprietaire");
				Registry registry3 = LocateRegistry.createRegistry(2011);
				registry3.rebind(name3, skeleton3);
				System.out.println("Serveur Waiting...");
				//
				Joueurinterface skeleton4 = (Joueurinterface) UnicastRemoteObject.exportObject(monint4,2012);
				String name4 = new String("rmi://serveurProprietaire");
				Registry registry4 = LocateRegistry.createRegistry(2012);
				registry4.rebind(name4, skeleton4);
				System.out.println("Serveur Waiting...");
				//
			}catch(java.rmi.server.ExportException e) {
			
				try {
					e.printStackTrace();
					UnicastRemoteObject.unexportObject(monint, true);
					System.out.println("Relancer le serveur...");
				}catch(Exception f) {f.printStackTrace();}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}catch(Exception g ) {
			g.printStackTrace();
		}
	}
	
}

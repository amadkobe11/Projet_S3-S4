package systeme;

public class JetonCoupDePouce extends Jeton {
	public JetonCoupDePouce() {
		super(-2);
	}
}

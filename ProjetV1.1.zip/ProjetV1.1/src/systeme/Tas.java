package systeme;

public abstract class Tas {
	public abstract boolean isEmpty();
	public abstract int getNbElement();
}

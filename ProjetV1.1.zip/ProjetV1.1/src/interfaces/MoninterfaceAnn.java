package interfaces;

import java.rmi.*;

public interface MoninterfaceAnn extends Remote {
	public int donneMoiport() throws RemoteException;
}
